﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gpa_calculator_Abdullah_bin_ata_38602
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


            if (textBox1.Text == "")
            {
                textBox1.BackColor = Color.Red;

            }
            else
            {
                int n1 = int.Parse(textBox1.Text);
                textBox1.BackColor = Color.White;
                if (n1 > 100)
                {
                    MessageBox.Show(" Your Marks should Be 1-100 ");
                }
            }

        }



        private void textBox2_TextChanged(object sender, EventArgs e)
        {

            if (textBox2.Text == "")
            {
                textBox2.BackColor = Color.Red;

            }
            else
            {
                int n1 = int.Parse(textBox2.Text);
                textBox2.BackColor = Color.White;
                if (n1 > 100)
                {
                    MessageBox.Show(" Your Marks should Be 1-100 ");
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

            if (textBox3.Text == "")
            {
                textBox3.BackColor = Color.Red;

            }
            else
            {
                int n1 = int.Parse(textBox3.Text);
                textBox3.BackColor = Color.White;
                if (n1 > 100)
                {
                    MessageBox.Show(" Your Marks should Be 1-100 ");
                }
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

            if (textBox4.Text == "")
            {
                textBox4.BackColor = Color.Red;

            }
            else
            {
                int n1 = int.Parse(textBox4.Text);
                textBox4.BackColor = Color.White;
                if (n1 > 100)
                {
                    MessageBox.Show(" Your Marks should Be 1-100 ");
                }
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

            if (textBox5.Text == "")
            {
                textBox5.BackColor = Color.Red;

            }
            else
            {
                int n1 = int.Parse(textBox5.Text);
                textBox5.BackColor = Color.White;
                if (n1 > 100)
                {
                    MessageBox.Show(" Your Marks should Be 1-100 ");
                }
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (textBox6.Text == "")
            {
                textBox6.BackColor = Color.Red;

            }
            else
            {
                int n1 = int.Parse(textBox6.Text);
                textBox6.BackColor = Color.White;
                if (n1 > 100)
                {
                    MessageBox.Show(" Your Marks should Be 1-100 ");
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                textBox1.Text = "0";
                comboBox1.Text="0";
                textBox1.Hide();
                comboBox1.Hide();
                label13.Text = "W";
            }
           



        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {


            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "" && textBox4.Text == "" && textBox5.Text == "" && textBox6.Text == "")
            {

                    MessageBox.Show("Enter all Number");

      
               
            }
            else
            {
                int t1 = Int32.Parse(textBox1.Text);
                int t2 = Int32.Parse(textBox2.Text);
                int t3 = Int32.Parse(textBox3.Text);
                int t4 = Int32.Parse(textBox4.Text);
                int t5 = Int32.Parse(textBox5.Text);
                int t6 = Int32.Parse(textBox6.Text);

                int c1 = Int32.Parse(comboBox1.Text);
                int c2 = Int32.Parse(comboBox2.Text);
                int c3 = Int32.Parse(comboBox3.Text);
                int c4 = Int32.Parse(comboBox4.Text);
                int c5 = Int32.Parse(comboBox5.Text);
                int c6 = Int32.Parse(comboBox6.Text);


               

                double gpa = GPA(t1) * c1 + GPA(t2) * c2 + GPA(t3) * c3 + GPA(t4) * c4 + GPA(t5) * c5+ GPA(t6) * c6;                  
                int Cr = c1 + c2 + c3 + c4 + c5 + c6;
                double Z = gpa / Cr;

                label11.Text = Z.ToString();





                label13.Text = Grade(t1);
                label14.Text = Grade(t2);
                label15.Text = Grade(t3);
                label16.Text = Grade(t4);
                label17.Text = Grade(t5);
                label18.Text = Grade(t6);

                label11.Visible = true;
                label13.Visible = true;
                label14.Visible = true;
                label15.Visible = true;
                label16.Visible = true;
                label17.Visible = true;
                label18.Visible = true;
                label19.Visible = true;


                if (checkBox1.Checked == true)
                {
                    textBox1.Dispose();
                    comboBox1.Dispose();
                    label13.Text = "W";
                 
                   


                }
                if (checkBox2.Checked == true)
                {
                    textBox2.Dispose();
                    comboBox2.Dispose();
                    label14.Text = "W";


                }
                if (checkBox3.Checked == true)
                {
                    textBox3.Dispose();
                    comboBox3.Dispose();
                    label15.Text = "W";


                }
                if (checkBox4.Checked == true)
                {
                    textBox4.Dispose();
                    comboBox4.Dispose();
                    label16.Text = "W";


                }
                if (checkBox5.Checked == true)
                {
                    textBox5.Dispose();
                    comboBox5.Dispose();
                    label17.Text = "W";


                }
                if (checkBox6.Checked == true)
                {
                    textBox6.Dispose();
                    comboBox6.Dispose();
                    label18.Text = "W";


                }



            }

            double GPA(int marks)
            {
                double A = 0.0;
                if (marks < 50)
                {
                    A = 0.0;
                }
                else if (marks >= 50 && marks <= 59)
                {
                    A = 1.0;
                }
                else if (marks >= 60 && marks <= 69)
                {
                    A = 2.0;
                }
                else if (marks >= 70 && marks <= 79)
                {
                    A = 3.0;
                }
                else if (marks >= 80 && marks <= 89)
                {
                    A = 4.0;
                }
                else if (marks >= 90 && marks <= 100)
                {
                    A = 4.0;
                }

                return A;
            }

            string Grade(int marks)
            {
                string A ="";
                if (marks < 50)
                {
                    A = "F";
                }
                else if (marks >= 50 && marks <= 59)
                {
                    A = "D";
                }
                else if (marks >= 60 && marks <= 69)
                {
                    A = "C";
                }
                else if (marks >= 70 && marks <= 79)
                {
                    A = "B";
                }
                else if (marks >= 80 && marks <= 89)
                {
                    A = "A";
                }
                else if (marks >= 90 && marks <= 100)
                {
                    A = "A+";
                }

                return A;
            }

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                textBox2.Text = "0";
                comboBox2.Text = "0";
                textBox2.Hide();
                comboBox2.Hide();
                label14.Text = "W";
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                textBox3.Text = "0";
                comboBox3.Text = "0";
                textBox3.Hide();
                comboBox3.Hide();
                label15.Text = "W";
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                textBox4.Text = "0";
                comboBox4.Text = "0";
                textBox4.Hide();
                comboBox4.Hide();
                label16.Text = "W";
            }

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                textBox5.Text = "0";
                comboBox5.Text = "0";
                textBox5.Hide();
                comboBox5.Hide();
                label17.Text = "W";
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                textBox6.Text = "0";
                comboBox6.Text = "0";
                textBox6.Hide();
                comboBox6.Hide();
                label18.Text = "W";
            }
        }

        
    }
}
